"""
This module provides a comprehensive distributed simulation framework for
launching and managing market simulations with parallel processing capabilities.

The simulation supports dynamic interactions between markets and investors using
Ray for distributed computing and async/await for concurrent processing.
"""

import logging
import importlib
import json
import uuid
import os
from datetime import datetime
from pathlib import Path
from collections import deque
from typing import Dict, List, Any, Optional, Tuple

import ray

from llmgt.utils import log_tag
from llmgt.utils.status import SimulatorStatus
from llmgt.proxy.market_proxy import GeneralMarketProxy
from llmgt.proxy.investor_proxy import GeneralInvestorProxy
from llmgt.market.base import BaseMarket, BaseMarketConfig, M2IMessage
from llmgt.investor.base import BaseInvestor, BaseInvestorConfig, I2MMessage
from llmgt.communication.general import GeneralM2IProtocol, GeneralI2MProtocol
from llmgt.communication.base import (
    BaseCommProtocol,
    ProtocolOutbound,
)
from llmgt.utils import record
from projinit.config import Config


def ensure_ray(init_kwargs: Optional[dict] = None) -> None:
    """
    Initialize Ray; if already connected but namespace differs, reconnect.
    Assumes Ray cluster is already running.
    """
    if init_kwargs is None:
        init_kwargs = {}

    target_ns = init_kwargs.get("namespace")

    if ray.is_initialized():
        try:
            current_ns = ray.get_runtime_context().namespace
            if current_ns == target_ns:
                return  # Already connected to correct namespace
        except Exception as e:
            logging.debug("Failed to get ray namespace: %r", e)

        ray.shutdown()

    # Simply connect
    ray.init(**init_kwargs)


def get_actor_name(prefix: str, investor_id: str) -> str:
    """
    Construct a deterministic Ray actor name from a prefix and investor id.
    """
    return f"{prefix}::{investor_id}"


def load_class(path: str) -> type:
    """
    Load a class from "module.submodule:ClassName" or "module.submodule.ClassName".
    """
    if ":" in path:
        module_path, cls_name = path.split(":", 1)
    else:
        module_path, cls_name = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, cls_name)


def instantiate_investor(
    investor_id: str,
    investor_config: Dict[str, Any],
    market_ids: List[str],
) -> BaseInvestor:
    """
    Instantiate an investor based on the class defined in the config.
    """
    class_path = investor_config["class"]
    investor_class = load_class(class_path)
    if not issubclass(investor_class, BaseInvestor):
        raise TypeError(f"{investor_class} is not a subclass of BaseInvestor.")
    inv_cfg_raw = investor_config["config"]
    inv_config = BaseInvestorConfig(identity=investor_id, extras=inv_cfg_raw)
    return investor_class(inv_config, market_ids)


def instantiate_market(
    market_id: str,
    market_config: Dict[str, Any],
    investor_ids: List[str],
) -> BaseMarket:
    """
    Instantiate a market based on the class defined in the config.
    """
    class_path = market_config["class"]
    market_cls = load_class(class_path)
    if not issubclass(market_cls, BaseMarket):
        raise TypeError(f"{market_cls} is not a subclass of BaseMarket.")
    mrk_cfg_raw = market_config["config"]
    market_config_obj = BaseMarketConfig(identity=market_id, extras=mrk_cfg_raw)
    return market_cls(market_config_obj, investor_ids)


def launch_investor_proxies(
    actor_prefix: str,
    ray_config: Dict[str, Any],
    investor_configs: Dict[str, Any],
    proxy_config: Dict[str, Any],
) -> Dict[str, ray.actor.ActorHandle]:
    """
    Launch the investors in the Ray environment.
    """
    ensure_ray(ray_config)
    handles: Dict[str, ray.actor.ActorHandle] = {}
    RemoteInvestorProxy = ray.remote(GeneralInvestorProxy)

    for inv_id in investor_configs:
        actor_name = get_actor_name(actor_prefix, inv_id)

        # Determine which markets this investor participates in
        market_ids = []
        inv_content = investor_configs[inv_id]
        if "market" in inv_content:
            if isinstance(inv_content["market"], list):
                market_ids = inv_content["market"]
            else:
                market_ids = [inv_content["market"]]

        inv_obj = instantiate_investor(inv_id, investor_configs[inv_id], market_ids)

        handle = RemoteInvestorProxy.options(
            name=actor_name,
            lifetime="detached",
            namespace=ray_config["namespace"],
        ).remote(inv_obj, proxy_config)

        logging.info(
            "%s Created an investor %s.",
            log_tag.BUILD_TAG,
            actor_name,
        )
        handles[inv_id] = handle

    return handles


def launch_market_proxies(
    actor_prefix: str,
    ray_config: Dict[str, Any],
    market_configs: Dict[str, Any],
    investor_configs: Dict[str, Any],
    proxy_config: Dict[str, Any],
) -> Dict[str, ray.actor.ActorHandle]:
    """
    Launch the markets in the Ray environment.
    """
    ensure_ray(ray_config)
    handles: Dict[str, ray.actor.ActorHandle] = {}
    RemoteMarketProxy = ray.remote(GeneralMarketProxy)

    for mrk_id in market_configs:
        actor_name = get_actor_name(actor_prefix, mrk_id)
        investor_ids = [
            inv_id
            for inv_id, inv_content in investor_configs.items()
            if "market" in inv_content and mrk_id in inv_content["market"]
        ]

        market_config = market_configs[mrk_id]
        market_impl = instantiate_market(mrk_id, market_config, investor_ids)

        handle = RemoteMarketProxy.options(
            name=actor_name,
            lifetime="detached",
            namespace=ray_config["namespace"],
        ).remote(market_impl, proxy_config)

        logging.info(
            "%s Created a market %s.",
            log_tag.BUILD_TAG,
            actor_name,
        )
        handles[mrk_id] = handle

    return handles


class Simulation:
    """
    This simulation supports both dynamic interactions between markets and investors.
    """

    def __init__(
        self,
        cfg: Dict[str, Any],
        m2i_protocol: BaseCommProtocol,
        i2m_protocol: BaseCommProtocol,
        *,
        actor_prefix: str = "agent",
        entry_limit: int = 10,
    ):
        """
        Initialize with support for demo-style persistent investors.
        """

        # Identity of the simulation
        self.simulation_id = os.getpid()

        # Basic configuration file
        self.cfg = cfg
        self.m2i_protocol = m2i_protocol or GeneralM2IProtocol()
        self.i2m_protocol = i2m_protocol or GeneralI2MProtocol()
        self.actor_prefix = actor_prefix

        self.total_rounds = int(self.cfg["model"]["num_rounds"])
        self.simulation_cfg = self.cfg["model"]["simulation"]
        self.ray_config: Dict[str, Any] = self.simulation_cfg["ray"]

        # Prepare proxy configuration
        self._proxy_config = {
            "api_keys": self.simulation_cfg["extras"].get("api_keys", {}),
            "env_overrides": self.simulation_cfg["extras"].get("env_overrides", {}),
        }

        result_path = Path(Config.logging.result_path)
        self.storage_dir = result_path / "simulation"
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        # Entry limit for in-memory history
        self.entry_limit = entry_limit
        self.history_entry = deque(maxlen=entry_limit)

        # Get the market id and the corresponding configuration
        markets_block = self.simulation_cfg["markets"]
        self._market_configs: Dict[str, Dict[str, Any]] = {
            mrk_id: mrk_cfg for mrk_id, mrk_cfg in markets_block.items()
        }
        # Get the investor id and the corresponding configuration
        investors_block = self.simulation_cfg["investors"]
        self._investor_configs: Dict[str, Dict[str, Any]] = {
            inv_id: inv_cfg for inv_id, inv_cfg in investors_block.items()
        }
        # Map the id in the config file to the corresponding ray actor handle
        self._investor_handles: Dict[str, ray.actor.ActorHandle] = {}
        self._market_handles: Dict[str, ray.actor.ActorHandle] = {}

        self.receive_status = SimulatorStatus.NO_RECEIVED
        self.running_status = SimulatorStatus.INITIALIZING
        self.alert_status = SimulatorStatus.NONE

        # Generate unique simulation ID
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_id = str(uuid.uuid4())[:8]
        self.simulation_id = f"sim_{timestamp}_{unique_id}"

        logging.info(
            "%s Generated simulation ID: %s", log_tag.BUILD_TAG, self.simulation_id
        )

    def get_round_entry(self, round_id: int) -> Any:
        """
        Get historical data for a specified round.
        """
        # Search in memory first
        entry = next(
            (item for item in self.history_entry if item.get("round_id") == round_id),
            None,
        )
        if entry:
            return entry["data"]

        # If not in memory, try to load from disk
        entry = record.load_record(
            self.storage_dir,
            f"round_{round_id:06d}",
            file_format="json",
            from_block=True,
        )

        return entry.get("data") if entry else None

    def _connect_market_proxies(self) -> Dict[str, ray.actor.ActorHandle]:
        """
        Connect to existing market proxies based on the config.
        """

        handles: Dict[str, ray.actor.ActorHandle] = {}
        namespace = self.ray_config["namespace"]

        for mrk_id in self._market_configs:
            actor_name = get_actor_name(self.actor_prefix, mrk_id)
            handle = ray.get_actor(actor_name, namespace=namespace)
            handles[mrk_id] = handle

        return handles

    def _connect_investor_proxies(self) -> Dict[str, ray.actor.ActorHandle]:
        """
        Connect to existing detached investor actors.
        """

        handles: Dict[str, ray.actor.ActorHandle] = {}
        namespace = self.ray_config["namespace"]

        for inv_id in self._investor_configs:
            actor_name = get_actor_name(self.actor_prefix, inv_id)
            handle = ray.get_actor(actor_name, namespace=namespace)
            handles[inv_id] = handle
        return handles

    async def _distribute_simulation_id(self):
        """
        Distribute the simulation ID to all market and investor actors.
        """
        logging.info(
            "%s Distributing simulation ID to all actors...", log_tag.BUILD_TAG
        )

        # Send to all investors
        investor_futures = []
        for inv_id, investor_handle in self._investor_handles.items():
            future = investor_handle.set_simulation_id.remote(self.simulation_id)
            investor_futures.append(future)

        # Send to all markets
        market_futures = []
        for market_id, market_handle in self._market_handles.items():
            future = market_handle.set_simulation_id.remote(self.simulation_id)
            market_futures.append(future)

        # Wait for all to complete
        ray.get(investor_futures + market_futures)

    async def _decision_for_investors(
        self,
        m2i_outbounds: List[ProtocolOutbound],
    ) -> List[I2MMessage]:
        """
        Perform the decision process of individual investors.
        """

        logging.info(
            "%s Starting investor decision process, sending %d M2I outbound messages",
            log_tag.START_TAG,
            len(m2i_outbounds),
        )

        # Dispatch messages to investors
        decisions = []
        for handle in self._investor_handles.values():
            decision_future = handle.perform_decision.remote(
                m2i_outbounds, self.m2i_protocol
            )
            decisions.append(decision_future)

        # Collect responses
        responses = ray.get(decisions)

        # Process responses
        merged: List[I2MMessage] = []
        for resp in responses:
            if resp is not None:
                merged.append(resp)

        logging.info(
            "%s%s Collected %d total I2M messages",
            log_tag.BLOCK_INDENT,
            log_tag.COMPLETE_TAG,
            len(merged),
        )

        return merged

    async def _decision_for_market(
        self,
        market_id: str,
        i2m_outbounds: List[ProtocolOutbound],
    ) -> Tuple[Optional[M2IMessage], Any]:
        """
        Process market decision.
        """
        logging.info(
            "%s%s Processing market decision for %s",
            log_tag.BLOCK_INDENT,
            log_tag.MARKET_TAG,
            market_id,
        )

        market_handle = self._market_handles[market_id]

        result: Optional[M2IMessage] = ray.get(
            market_handle.perform_decision.remote(i2m_outbounds, self.i2m_protocol)
        )

        if result is not None:
            logging.info(
                "%s%s Generated M2I message for next round from market %s",
                log_tag.BLOCK_INDENT,
                log_tag.SEND_TAG,
                market_id,
            )
            return result, result.decision_content
        else:
            logging.info(
                "%s%s No decision made by market %s",
                log_tag.BLOCK_INDENT,
                log_tag.SEND_TAG,
                market_id,
            )
            return None, None

    async def run(self) -> List[Any]:
        """
        Run simulation with concurrent processing for both investors and markets.
        """
        ensure_ray(self.ray_config)
        self.running_status = SimulatorStatus.RUNNING

        logging.info(
            "%s Starting simulation with ID: %s", log_tag.START_TAG, self.simulation_id
        )

        # Connect to the proxies of all markets and investors
        self._investor_handles = self._connect_investor_proxies()
        self._market_handles = self._connect_market_proxies()

        # Send the simulation ID to proxies of all markets and investors to
        # enable the consistency

        self.receive_status = SimulatorStatus.WELL_RECEIVED

        # Distribute simulation ID to all actors
        await self._distribute_simulation_id()

        for round_num in range(1, int(self.total_rounds) + 1):
            logging.info("%s Starting round %d", log_tag.START_TAG, round_num)

            # 1. Always call build_initial_m2i_messages
            initial_message_futures = []
            for market_id, market_handle in self._market_handles.items():
                future = market_handle.build_initial_m2i_messages.remote(round_num)
                initial_message_futures.append(future)

            all_market_messages = ray.get(initial_message_futures)

            # Flatten messages
            initial_messages = []
            for market_messages in all_market_messages:
                initial_messages.extend(market_messages)

            # Encode all messages
            m2i_outbounds = self.m2i_protocol.encode(initial_messages)

            # 2. Filter and deliver M2I messages to investors
            i2m_results = []
            for inv_id, investor_handle in self._investor_handles.items():
                filtered_outbounds = [
                    outbound
                    for outbound in m2i_outbounds
                    if f"investor::{inv_id}" in outbound.head
                ]
                decisions = investor_handle.perform_decision.remote(
                    filtered_outbounds, self.m2i_protocol
                )
                i2m_results.append(decisions)

            investor_results = ray.get(i2m_results)

            # Collect I2M messages
            i2m_messages = []
            for result in investor_results:
                i2m_messages.extend(result)

            i2m_outbounds = self.i2m_protocol.encode(i2m_messages)

            # 3. Filter and deliver I2M messages to markets
            m2i_results = []
            market_ids = []
            for market_id, market_handle in self._market_handles.items():
                filtered_outbounds = []
                for outbound in i2m_outbounds:
                    data = json.loads(outbound.data)
                    payload = data["payload"]
                    if payload["market_id"] == market_id:
                        filtered_outbounds.append(outbound)

                decision = market_handle.perform_decision.remote(
                    filtered_outbounds, self.i2m_protocol
                )
                m2i_results.append(decision)
                market_ids.append(market_id)

            market_results = ray.get(m2i_results)

            # Collect round decisions
            next_round_messages = []
            round_decisions = {}
            for market_id, result in zip(market_ids, market_results):
                round_decisions[market_id] = result.decision_content

            # Save round data
            round_record = {"round_id": round_num, "data": round_decisions}
            record.save_record(
                round_record,
                self.storage_dir,
                f"round_{round_num:06d}",
                file_format="json",
                as_block=True,
            )
            self.history_entry.append(round_record)

            logging.info(
                "%s%s Completed simulation round %d",
                log_tag.BLOCK_INDENT,
                log_tag.COMPLETE_TAG,
                round_num,
            )

        logging.info(
            "%s Simulation completed successfully! Generated %d rounds of results",
            log_tag.COMPLETE_TAG,
            self.total_rounds,
        )

        self.running_status = SimulatorStatus.TERMINATED
        return [self.running_status]
